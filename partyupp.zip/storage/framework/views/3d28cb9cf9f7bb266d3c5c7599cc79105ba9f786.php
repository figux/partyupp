<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Editar
                </div>

                <div class="card-body">

                    <form name="bar" method="POST" action="<?php echo e(route('barUpdate', ['id'=>$bar->id])); ?>">
                        
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nombre</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e($bar->name); ?>" >
                        </div>
                        <div class="form-group">
                            <label for="exampleTextarea">Descripcion</label>
                            <textarea class="form-control"  rows="3" name="description" ><?php echo e($bar->description); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="exampleTextarea">Cover</label>  
                            <input type="number" rows="3" name="cover" value="<?php echo e($bar->cover); ?>">
                        </div>
                        <div class="form-group">
                            <label for="exampleText">Estado</label>  
                            <input type="numbre" name="state" value="<?php echo e($bar->state); ?>">
                        </div>

                        <button type="submit" class="btn btn-primary">Actualizar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>