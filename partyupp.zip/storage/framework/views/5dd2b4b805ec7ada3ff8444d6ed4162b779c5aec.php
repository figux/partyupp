<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                	Dashboard
 	
                	<a href="<?php echo e(route('barCrear')); ?>" class="btn btn-primary" >Crear Bar</a>
                </div>

                <div class="card-body">
                    <table class="table">

                    	<thead>
                    		<tr>
                    			<td>Nombre</td>
                    			<td>Calificacion</td>
                    			<td>Estado</td>
                    			<td>Reseñas</td>
                    			<td>Opciones</td>
                    		</tr>
                    	</thead>
                    	<tbody>
                    		<?php $__currentLoopData = $bares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    		<tr>
                    			<td>
                    				<?php echo e($bar->name); ?>

                    			</td>
                    			<td>
                    				<?php echo e($bar->rate); ?>

                    			</td>
                    			<td>
                    				<?php if($bar->state == 0): ?>
                    				 	<span class="badge badge-danger">No Activo</span>
                    				<?php else: ?>
                    					<span class="badge badge-success">Activo</span>
                    				<?php endif; ?>
                    			</td>
                    			<td>
                    			<a> Ver</a>                    				
                    			</td>
                    			<td>
                    			<a class="btn btn-secondary" href="<?php echo e(route('barEdit', $bar->id)); ?>" > Editar</a>
                    			<a class="btn btn-warning" href="<?php echo e(route('barDelete', $bar->id)); ?>"> Eliminar</a>                    				
                    			</td>
                    		</tr>
                    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    	</tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>